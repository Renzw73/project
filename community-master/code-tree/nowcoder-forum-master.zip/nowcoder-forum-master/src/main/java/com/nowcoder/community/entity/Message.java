package com.nowcoder.community.entity;

import java.util.Date;

/**
 * 私信消息表
 * @author Alex
 * @version 1.0
 * @date 2022/2/9 16:26
 */
public class Message {
    private int id;
    /**
     * 发信人id
     *      如果是系统发送通知，则fromId为1
     */
    private int fromId;
    /**
     * 收信人id
     */
    private int toId;
    /**
     * 会话id
     */
    private String conversationId;
    private String content;
    /**
     * 状态
     *  0-未读;1-已读;2-删除;
     */
    private int status;
    private Date createTime;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getFromId() {
        return fromId;
    }

    public void setFromId(int fromId) {
        this.fromId = fromId;
    }

    public int getToId() {
        return toId;
    }

    public void setToId(int toId) {
        this.toId = toId;
    }

    public String getConversationId() {
        return conversationId;
    }

    public void setConversationId(String conversationId) {
        this.conversationId = conversationId;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    @Override
    public String toString() {
        return "Message{" +
                "id=" + id +
                ", fromId=" + fromId +
                ", toId=" + toId +
                ", conversationId='" + conversationId + '\'' +
                ", content='" + content + '\'' +
                ", status=" + status +
                ", createTime=" + createTime +
                '}';
    }
}
